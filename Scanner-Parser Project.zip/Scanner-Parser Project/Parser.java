import java.util.*;

public class Parser {

    private final ArrayList<Token> tokens;
    private int current = 0;

    public Parser(ArrayList<Token> tokens) {
        this.tokens = tokens;
    }

    private Token currentToken() {
        if (current >= tokens.size()) {
            return new Token("EOF", "EOF");
        }
        return tokens.get(current);
    }

    private void advance() {
        current++;
    }

    private void match(String expected) {
        if (currentToken().value.equals(expected)) {
            advance();
        } else {
            throw new RuntimeException(
                "Expected: " + expected + " Found: " + currentToken().value
            );
        }
    }

    public void parse() {
        if (tokens.isEmpty()) {
            throw new RuntimeException("No tokens. Please Scan first.");
        }
        for (Token t : tokens) {
            if ("Invalid Token".equals(t.type)) {
                throw new RuntimeException("Invalid token: " + t.value);
            }
        }

        classRule();

        if (current < tokens.size()) {
            throw new RuntimeException("Unexpected Token: " + currentToken().value);
        }
    }

    // S -> class
    // class -> class_signature { data_declaration constructor method }
    private void classRule() {
        classSignature();
        match("{");

        while (isDataDeclaration()) {
            dataDeclaration();
        }

        constructor();

        while (isMethod()) {
            method();
        }

        match("}");
    }

    private boolean isDataDeclaration() {
        if (!isAccessModifier(currentToken().value)) {
            return false;
        }
        int save = current;
        try {
            accessModifier();
            if (currentToken().value.equals("static")) {
                advance();
            }
            if (!isDataType(currentToken().value)) {
                return false;
            }
            dataType();
            identifier();
            return currentToken().value.equals(";");
        } finally {
            current = save;
        }
    }

    private boolean isMethod() {
        if (!isAccessModifier(currentToken().value)) {
            return false;
        }
        int save = current;
        try {
            accessModifier();
            if (currentToken().value.equals("void")) {
                advance();
            } else if (isDataType(currentToken().value)) {
                dataType();
            } else {
                return false;
            }
            identifier();
            return currentToken().value.equals("(");
        } finally {
            current = save;
        }
    }

    private void classSignature() {
        match("public");
        match("class");
        identifier();
    }

    // data_declaration -> access_modifier static data_type identifier; data_declaration | e
    private void dataDeclaration() {
        accessModifier();
        if (currentToken().value.equals("static")) {
            advance();
        }
        dataType();
        identifier();
        match(";");
    }

    // constructor -> constructor_signature { statements }
    private void constructor() {
        accessModifier();
        identifier();
        match("(");
        parameterList();
        match(")");
        match("{");
        statements();
        match("}");
    }

    // method -> method_signature { statements return_statement }
    private void method() {
        accessModifier();
        returnType();
        identifier();
        match("(");
        parameterList();
        match(")");
        match("{");
        statements();
        returnStatement();
        match("}");
    }

    // statements -> assignment statements | function_call statements | conditions statements | e
    private void statements() {
        while (isStatement()) {
            if (currentToken().value.equals("if")) {
                ifCondition();
            } else if (isDataType(currentToken().value)) {
                localDeclaration();
                match("=");
                expression();
                match(";");
            } else if (
                currentToken().value.equals("this")
                || currentToken().type.equals("Identifier")
            ) {
                int save = current;
                advance();
                if (currentToken().value.equals("=") || currentToken().value.equals(".")) {
                    current = save;
                    assignment();
                } else if (currentToken().value.equals("(")) {
                    current = save;
                    functionCall();
                } else {
                    throw new RuntimeException("Invalid Statement");
                }
            }
        }
    }

    private boolean isStatement() {
        String v = currentToken().value;
        return v.equals("if")
            || isDataType(v)
            || v.equals("this")
            || currentToken().type.equals("Identifier");
    }

    // assignment -> identifier = expression; | this.identifier = expression;
    private void assignment() {
        if (currentToken().value.equals("this")) {
            match("this");
            match(".");
        }
        identifier();
        match("=");
        expression();
        match(";");
    }

    // expression -> identifier | digit | expression arith_operator expression
    private void expression() {
        operand();
        while (isArithOperator(currentToken().value)) {
            advance();
            operand();
        }
    }

    private void operand() {
        if (currentToken().type.equals("Identifier")) {
            identifier();
        } else if (currentToken().type.equals("Number")) {
            advance();
        } else {
            throw new RuntimeException("Invalid Expression");
        }
    }

    // function_call -> identifier ( argument_list ); | this.identifier ( argument_list );
    private void functionCall() {
        if (currentToken().value.equals("this")) {
            match("this");
            match(".");
        }
        identifier();
        match("(");
        argumentList();
        match(")");
        match(";");
    }

    // if_condition -> if ( predicate ) { statements }
    private void ifCondition() {
        match("if");
        match("(");
        predicate();
        match(")");
        match("{");
        statements();
        match("}");
    }

    // predicate -> identifier rel_operator identifier | identifier rel_operator digit
    private void predicate() {
        identifier();
        relOperator();
        if (currentToken().type.equals("Identifier") || currentToken().type.equals("Number")) {
            advance();
        } else {
            throw new RuntimeException("Invalid Predicate");
        }
    }

    // return_statement -> return identifier | return integer | e
    private void returnStatement() {
        if (currentToken().value.equals("return")) {
            match("return");
            if (currentToken().type.equals("Identifier") || currentToken().type.equals("Number")) {
                advance();
            }
            match(";");
        }
    }

    // parameter_list -> parameter | parameter , parameter_list | e
    private void parameterList() {
        if (isDataType(currentToken().value)) {
            parameter();
            while (currentToken().value.equals(",")) {
                match(",");
                parameter();
            }
        }
    }

    private void parameter() {
        dataType();
        identifier();
    }

    // argument_list -> identifier | identifier , argument_list | e
    private void argumentList() {
        if (currentToken().type.equals("Identifier")) {
            identifier();
            while (currentToken().value.equals(",")) {
                match(",");
                identifier();
            }
        }
    }

    // local_declaration -> data_type identifier
    private void localDeclaration() {
        dataType();
        identifier();
    }

    // return_type -> void | data_type
    private void returnType() {
        if (currentToken().value.equals("void")) {
            match("void");
        } else {
            dataType();
        }
    }

    private void relOperator() {
        String op = currentToken().value;
        if (op.equals("<") || op.equals("<=") || op.equals(">")
            || op.equals(">=") || op.equals("==") || op.equals("!=")) {
            advance();
        } else {
            throw new RuntimeException("Relational Operator Expected");
        }
    }

    private void accessModifier() {
        if (isAccessModifier(currentToken().value)) {
            advance();
        } else {
            throw new RuntimeException("Access Modifier Expected");
        }
    }

    private boolean isAccessModifier(String t) {
        return t.equals("public") || t.equals("private");
    }

    private void dataType() {
        if (isDataType(currentToken().value)) {
            advance();
        } else {
            throw new RuntimeException("Data Type Expected");
        }
    }

    private boolean isDataType(String t) {
        return t.equals("byte") || t.equals("short")
            || t.equals("int") || t.equals("long");
    }

    private boolean isArithOperator(String t) {
        return t.equals("+") || t.equals("-") || t.equals("*")
            || t.equals("/") || t.equals("%");
    }

    private void identifier() {
        if (currentToken().type.equals("Identifier")) {
            advance();
        } else {
            throw new RuntimeException("Identifier Expected");
        }
    }
}
